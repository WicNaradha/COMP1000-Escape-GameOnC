#ifndef TERMINAL_H
#define TERMINAL_H

#include "macros.h"

void disableBuffer();
void enableBuffer();

#endif